codeunit 50001 "Subscriber Events"
{
    Permissions = tabledata "Sales Header" = rimd;
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Sales-Quote to Order", 'OnAfterTransferQuoteToOrderLines', '', false, false)]
    local procedure OnSalesQuotetoOrderOnAfterTransferQuotetoOrderLines(var SalesQuoteLine: Record "Sales Line"; var SalesQuoteHeader: Record "Sales Header")
    var
        SalesOrderHeader: Record "Sales Header";
    begin
        SalesOrderHeader.Reset();
        SalesOrderHeader.SetRange("Document Type", SalesOrderHeader."Document Type"::Order);
        SalesOrderHeader.SetRange("Quote No.", SalesQuoteHeader."No.");
        if SalesOrderHeader.FindFirst() then begin
            SalesOrderHeader.Status := SalesOrderHeader.Status::Released;
            SalesOrderHeader.Modify(true);
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Sales Header", 'OnAfterValidateEvent', 'BL Date', false, false)]
    local procedure OnSalesHeaderAfterValidateOnPromisedDeliveryDateChanged(var Rec: Record "Sales Header")
    var
        Customer: Record Customer;
        PaymentTerm: Record "Payment Terms";
        PaymentTermDuration: DateFormula;
    begin
        if Rec."Payment Terms Code" <> '' then
            if PaymentTerm.Get(Rec."Payment Terms Code") then
                PaymentTermDuration := PaymentTerm."Due Date Calculation";
        if FORMAT(PaymentTermDuration) <> '' then
            if FORMAT(Rec."BL Date") <> '' then
                Rec.Validate("Due Date", CalcDate(PaymentTermDuration, Rec."BL Date"));
    end;

    [EventSubscriber(ObjectType::Table, Database::"Sales Header", 'OnAfterValidateEvent', 'Payment Terms Code', false, false)]
    local procedure OnSalesHeaderAfterValidateOnPaymentTermsCodeChanged(var Rec: Record "Sales Header")
    var
        Vendor: Record Vendor;
        PaymentTerm: Record "Payment Terms";
        PaymentTermDuration: DateFormula;
    begin
        if Rec."Payment Terms Code" <> '' then
            if PaymentTerm.Get(Rec."Payment Terms Code") then
                PaymentTermDuration := PaymentTerm."Due Date Calculation";
        if FORMAT(PaymentTermDuration) <> '' then
            if FORMAT(Rec."BL Date") <> '' then
                Rec.Validate("Due Date", CalcDate(PaymentTermDuration, Rec."BL Date"));
    end;

    [EventSubscriber(ObjectType::Table, Database::"Purchase Header", 'OnAfterValidateEvent', 'BL Date', false, false)]
    local procedure OnPurchaseHeaderAfterValidateOnRequestedReceiptDateChanged(var Rec: Record "Purchase Header")
    var
        Vendor: Record Vendor;
        PaymentTerm: Record "Payment Terms";
        PaymentTermDuration: DateFormula;
    begin
        if Rec."Payment Terms Code" <> '' then
            if PaymentTerm.Get(Rec."Payment Terms Code") then
                PaymentTermDuration := PaymentTerm."Due Date Calculation";
        if FORMAT(PaymentTermDuration) <> '' then
            if FORMAT(Rec."BL Date") <> '' then
                Rec.Validate("Due Date", CalcDate(PaymentTermDuration, Rec."BL Date"));
    end;

    [EventSubscriber(ObjectType::Table, Database::"Purchase Header", 'OnAfterValidateEvent', 'Payment Terms Code', false, false)]
    local procedure OnPurchaseHeaderAfterValidateOnPaymentTermsCodeChanged(var Rec: Record "Purchase Header")
    var
        Vendor: Record Vendor;
        PaymentTerm: Record "Payment Terms";
        PaymentTermDuration: DateFormula;
    begin
        if Rec."Payment Terms Code" <> '' then
            if PaymentTerm.Get(Rec."Payment Terms Code") then
                PaymentTermDuration := PaymentTerm."Due Date Calculation";
        if FORMAT(PaymentTermDuration) <> '' then
            if FORMAT(Rec."BL Date") <> '' then
                Rec.Validate("Due Date", CalcDate(PaymentTermDuration, Rec."BL Date"));
    end;

    [EventSubscriber(ObjectType::Table, Database::"Transfer Shipment Header", 'OnAfterCopyFromTransferHeader', '', false, false)]
    local procedure OnTransferShipmentHeaderOnAfterCopyFromTransferHeader(TransferHeader: Record "Transfer Header"; var TransferShipmentHeader: Record "Transfer Shipment Header")
    var
        TranShipHeader: Record "Transfer Shipment Header";
        Text001: Label 'Box No. %1 is already Assigned';
    begin
        TransferShipmentHeader."Reason Code" := TransferHeader."Reason Code";
    end;

    [EventSubscriber(ObjectType::Table, Database::"Transfer Receipt Header", 'OnAfterCopyFromTransferHeader', '', false, false)]
    local procedure OnTransferReceiptHeaderOnAfterCopyFromTransferHeader(TransferHeader: Record "Transfer Header"; var TransferReceiptHeader: Record "Transfer Receipt Header")
    var
        TranRecHeader: Record "Transfer Receipt Header";
        Text001: Label 'Box No. %1 is already Assigned';
    begin
        TransferReceiptHeader."Reason Code" := TransferHeader."Reason Code";
    end;

    [EventSubscriber(ObjectType::codeunit, codeunit::"TransferOrder-Post Shipment", 'OnAfterCreateItemJnlLine', '', false, false)]
    local procedure OnTransferOrderPostShipmentOnAfterCreateItemJnlLine(var ItemJournalLine: Record "Item Journal Line"; TransferShipmentLine: Record "Transfer Shipment Line"; TransferShipmentHeader: Record "Transfer Shipment Header")
    begin
        ItemJournalLine."Reason Code" := TransferShipmentLine."Reason Code";

    end;

    [EventSubscriber(ObjectType::codeunit, codeunit::"TransferOrder-Post Receipt", 'OnBeforePostItemJournalLine', '', false, false)]
    local procedure OnTransferOrderPostReceiptOnAfterCreateItemJnlLine(var ItemJournalLine: Record "Item Journal Line"; TransferReceiptLine: Record "Transfer Receipt Line"; TransferReceiptHeader: Record "Transfer Receipt Header")
    begin
        ItemJournalLine."Reason Code" := TransferReceiptLine."Reason Code";

    end;

    [EventSubscriber(ObjectType::Table, Database::"Transfer Shipment Line", 'OnAfterCopyFromTransferLine', '', false, false)]
    local procedure OnTransferShipmentLineOnAfterCopyFromTransferLine(TransferLine: Record "Transfer Line"; var TransferShipmentLine: Record "Transfer Shipment Line")
    begin
        TransferShipmentLine."Reason Code" := TransferLine."Reason Code";

    end;

    [EventSubscriber(ObjectType::Table, Database::"Transfer Receipt Line", 'OnAfterCopyFromTransferLine', '', false, false)]
    local procedure OnTransferReceiptLineOnAfterCopyFromTransferLine(TransferLine: Record "Transfer Line"; var TransferReceiptLine: Record "Transfer Receipt Line")
    begin
        TransferReceiptLine."Reason Code" := TransferLine."Reason Code";
    end;

    [EventSubscriber(ObjectType::codeunit, codeunit::"Item Jnl.-Post Line", 'OnBeforeInsertItemLedgEntry', '', false, false)]
    local procedure OnItemJnlPostLineOnBeforeInsertItemLedgEntry(var ItemLedgerEntry: Record "Item Ledger Entry"; ItemJournalLine: Record "Item Journal Line")
    var
        SourceCodeSetup: Record "Source Code Setup";
        ILE: Record "Item Ledger Entry";
        ItemTracking: Record "Item Tracking Code";
        Item: Record Item;
    begin
        ItemLedgerEntry."Reason Code" := ItemJournalLine."Reason Code";

    end;
}