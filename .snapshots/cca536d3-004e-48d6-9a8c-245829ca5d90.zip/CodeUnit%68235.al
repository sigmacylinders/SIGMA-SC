codeunit 68235 "Payment Terms Utilities"
{
    var
        PaymentTermsDetails: Record "Payment Terms Detail";
        DocPaymentTerms: Record "Document Payment Terms";
        DocSource: Option Sales,Purchase;
        PaymentTermsTotal100: Label 'Payment Term Details Percentage must total to 100';

    procedure IsMultiPaymentTerm(PaymentTermCode: Code[10]) IsMulti: Boolean;
    begin
        PaymentTermsDetails.RESET;
        PaymentTermsDetails.SETRANGE(PaymentTermsDetails."Payment Term Code", PaymentTermCode);
        IsMulti := (PaymentTermsDetails.COUNT > 0);
    end;

    procedure GetHeaderDocumentDate(HeaderDocType: Enum "Document Type"; HeaderDocNo: Code[20]; HeaderDocSource: Option Sales,Purchase; var RecordFound: Boolean) DocumentDate: Date;
    var
        SalesHeader: Record "Sales Header";
        PurchaseHeader: Record "Purchase Header";
    begin
        CASE HeaderDocSource OF
            HeaderDocSource::Sales:
                BEGIN
                    SalesHeader.RESET;
                    SalesHeader.SETRANGE("Document Type", HeaderDocType);
                    SalesHeader.SETRANGE("No.", HeaderDocNo);
                    IF SalesHeader.FINDFIRST THEN BEGIN
                        RecordFound := TRUE;
                        DocumentDate := SalesHeader."Document Date";
                    END;
                END;
            HeaderDocSource::Purchase:
                BEGIN
                    PurchaseHeader.RESET;
                    PurchaseHeader.SETRANGE("Document Type", HeaderDocType);
                    PurchaseHeader.SETRANGE("No.", HeaderDocNo);
                    IF PurchaseHeader.FINDFIRST THEN BEGIN
                        RecordFound := TRUE;
                        DocumentDate := PurchaseHeader."Document Date";
                    END;
                END;
        END;
    end;

    procedure ClearPaymentTermDetails(DocumentType: Enum "Document Type";
    DocumentNo: Code[20];
    DocSource: Option Sales,Purchase);
    begin
        DocPaymentTerms.RESET;
        DocPaymentTerms.SETRANGE("Document Type", DocumentType);
        DocPaymentTerms.SETRANGE("Document No.", DocumentNo);
        DocPaymentTerms.SETRANGE("Document Source", DocSource);
        IF DocPaymentTerms.FINDFIRST THEN
            DocPaymentTerms.DELETEALL;
    end;

    procedure AddPaymentTermDetails(DocumentType: Enum "Document Type"; DocumentNo: Code[20]; DocumentSource: Option; DocumentAmount: Decimal; DocumentDate: Date; PaymentTermCode: Code[10]);
    var
        LineNo: Integer;
        RecordFound: Boolean;
        TotalPercent: Decimal;
        TotalAmount: Decimal;
    begin
        PaymentTermsDetails.RESET;
        PaymentTermsDetails.SETRANGE(PaymentTermsDetails."Payment Term Code", PaymentTermCode);
        PaymentTermsDetails.SETCURRENTKEY(Percentage, "Due Date Calculation");
        IF PaymentTermsDetails.FINDFIRST THEN BEGIN
            DocPaymentTerms.RESET;
            REPEAT
                DocPaymentTerms.INIT;
                DocPaymentTerms."Document Type" := DocumentType;
                DocPaymentTerms."Document No." := DocumentNo;
                DocPaymentTerms."Document Source" := DocumentSource;
                DocPaymentTerms."Payment Term Code" := PaymentTermCode;
                DocPaymentTerms."Due Date Calculation" := PaymentTermsDetails."Due Date Calculation";
                DocPaymentTerms."Due Date" := CALCDATE(DocPaymentTerms."Due Date Calculation", DocumentDate);
                DocPaymentTerms.Percentage := PaymentTermsDetails.Percentage;
                TotalPercent += DocPaymentTerms.Percentage;
                DocPaymentTerms.Description := PaymentTermsDetails.Description;
                LineNo := LineNo + 10000;
                DocPaymentTerms."Line No." := LineNo;
                DocPaymentTerms.INSERT;
            UNTIL PaymentTermsDetails.NEXT = 0
        END
    end;

    procedure GetHeaderAmount(DocumentType: Enum "Document Type"; DocumentNo: Code[20]; DocumentSource: Option Sales,Purchase; var RecordFound: Boolean) DocumentAmount: Decimal;
    var
        SalesHeader: Record "Sales Header";
        PurchaseHeader: Record "Purchase Header";
        GLSetup: Record "General Ledger Setup";
    begin
        GLSetup.Get();
        CASE DocumentSource OF
            DocumentSource::Sales:
                BEGIN
                    SalesHeader.RESET;
                    SalesHeader.SETRANGE("Document Type", DocumentType);
                    SalesHeader.SETRANGE("No.", DocumentNo);
                    IF SalesHeader.FINDFIRST THEN BEGIN
                        RecordFound := TRUE;
                        SalesHeader.CalcFields("Amount Including VAT");
                        DocumentAmount := SalesHeader."Amount Including VAT";
                    END
                END;
            DocumentSource::Purchase:
                BEGIN
                    PurchaseHeader.RESET;
                    PurchaseHeader.SETRANGE("Document Type", DocumentType);
                    PurchaseHeader.SETRANGE("No.", DocumentNo);
                    IF PurchaseHeader.FINDFIRST THEN BEGIN
                        RecordFound := TRUE;
                        PurchaseHeader.CalcFields("Amount Including VAT");
                        DocumentAmount := PurchaseHeader."Amount Including VAT";
                    END
                END;
        END;
    end;

    procedure UpdateDocPaymentTerms(DocumentType: Enum "Document Type";
    DocumentNo: Code[20];
    DocumentSource: Option;
    DocumentDate: Date);
    begin
        DocPaymentTerms.SETRANGE("Document Type", DocumentType);
        DocPaymentTerms.SETRANGE("Document No.", DocumentNo);
        DocPaymentTerms.SETRANGE("Document Source", DocumentSource);
        IF DocPaymentTerms.FINDFIRST THEN
            REPEAT
                DocPaymentTerms.VALIDATE(Percentage);
                DocPaymentTerms."Due Date" := CALCDATE(DocPaymentTerms."Due Date Calculation", DocumentDate);
                DocPaymentTerms.MODIFY;
            UNTIL DocPaymentTerms.NEXT = 0
    end;

    [EventSubscriber(ObjectType::Table, 37, 'OnAfterModifyEvent', '', false, false)]
    local procedure SalesLineOnAfterUpdate(var Rec: Record "Sales Line";
    var xRec: Record "Sales Line";
    RunTrigger: Boolean);
    var
        DocSource: Option Sales,Purchase;
        SalesHeader: Record "Sales Header";
    begin
        IF Rec."Amount Including VAT" <> xRec."Amount Including VAT" THEN BEGIN
            DocSource := DocSource::Sales;
            SalesHeader.GET(Rec."Document Type", Rec."Document No.");
            UpdateDocPaymentTerms(Rec."Document Type", Rec."Document No.", DocSource, SalesHeader."Document Date");
        END
    end;

    procedure TestDocMultiPaymentTerms(DocumentType: Option;
    DocumentNo: Code[20];
    DocumentSource: Option Sales,Purchase);
    begin
        DocPaymentTerms.RESET;
        DocPaymentTerms.SETRANGE("Document Type", DocumentType);
        DocPaymentTerms.SETRANGE("Document No.", DocumentNo);
        DocPaymentTerms.SETRANGE("Document Source", DocumentSource);
        IF DocPaymentTerms.FINDFIRST THEN
            REPEAT
                DocPaymentTerms.TESTFIELD("Due Date");
            UNTIL DocPaymentTerms.NEXT = 0
    end;

    [EventSubscriber(ObjectType::Table, 39, 'OnAfterModifyEvent', '', false, false)]
    local procedure PurchLineOnAfterUpdate(var Rec: Record "Purchase Line";
    var xRec: Record "Purchase Line";
    RunTrigger: Boolean);
    var
        DocSource: Option Sales,Purchase;
        PurchaseHeader: Record "Purchase Header";
    begin
        IF Rec."Amount Including VAT" <> xRec."Amount Including VAT" THEN BEGIN
            DocSource := DocSource::Purchase;
            PurchaseHeader.GET(Rec."Document Type", Rec."Document No.");
            UpdateDocPaymentTerms(Rec."Document Type", Rec."Document No.", DocSource, PurchaseHeader."Document Date");
        END
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Purch. Post Invoice Events", 'OnPostLedgerEntryOnBeforeGenJnlPostLine', '', false, false)]
    local procedure OnPurchPostOnBeforePostVendorEntry(VAR GenJnlLine: Record "Gen. Journal Line";
    VAR PurchHeader: Record "Purchase Header";
    VAR TotalPurchLine: Record "Purchase Line";
    VAR TotalPurchLineLCY: Record "Purchase Line")
    var
        Perc: Decimal;
        GenJnlLine2: Record "Gen. Journal Line";
        GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line";
        GLSetup: Record "General Ledger Setup";
        AmtRounding: Decimal;
        Currency: Record Currency;
        Amt: Decimal;
        AmtLCY: Decimal;
    begin
        if PurchHeader."Currency Code" <> '' then begin
            Currency.get(PurchHeader."Currency Code");
            AmtRounding := Currency."Amount Rounding Precision";
        end
        else begin
            GLSetup.get;
            AmtRounding := GLSetup."Amount Rounding Precision";
        end;
        Amt := TotalPurchLine."Amount Including VAT";
        AmtLCY := TotalPurchLineLCY."Amount Including VAT";

        if not IsMultiPaymentTerm(PurchHeader."Payment Terms Code") then begin
            GenJnlLine.Amount := -Amt;
            GenJnlLine."Source Currency Amount" := -Amt;
            GenJnlLine."Amount (LCY)" := round((-AmtLCY), AmtRounding);
            GenJnlLine."Sales/Purch. (LCY)" := round((-AmtLCY), AmtRounding);
            GenJnlLine."Inv. Discount (LCY)" := round((-TotalPurchLineLCY."Inv. Discount Amount"), AmtRounding);
            exit;

        end;

        DocPaymentTerms.RESET;
        DocPaymentTerms.SETRANGE("Document Type", PurchHeader."Document Type");
        DocPaymentTerms.SETRANGE("Document No.", PurchHeader."No.");
        DocPaymentTerms.SETRANGE("Document Source", DocPaymentTerms."Document Source"::Purchase);
        IF DocPaymentTerms.FINDFIRST THEN begin
            Perc := DocPaymentTerms.Percentage / 100;
            GenJnlLine."Recurring Method" := GenJnlLine."Recurring Method"::"V  Variable";
            GenJnlLine.Amount := -Amt * Perc;
            GenJnlLine."Source Currency Amount" := -Amt * Perc;
            GenJnlLine."Amount (LCY)" := round((-AmtLCY * Perc), AmtRounding);
            GenJnlLine."Sales/Purch. (LCY)" := round((-AmtLCY * Perc), AmtRounding);
            GenJnlLine."Inv. Discount (LCY)" := round((-TotalPurchLineLCY."Inv. Discount Amount" * Perc), AmtRounding);
            GenJnlLine."Due Date" := DocPaymentTerms."Due Date";
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Purch. Post Invoice Events", 'OnPostLedgerEntryOnAfterGenJnlPostLine', '', false, false)]
    local procedure OnPurchPostOnAfterPostVendorEntry(VAR GenJnlLine: Record "Gen. Journal Line";
    VAR PurchHeader: Record "Purchase Header";
    VAR TotalPurchLine: Record "Purchase Line";
    VAR TotalPurchLineLCY: Record "Purchase Line";
    VAR GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line")
    var
        Perc: Decimal;
        GenJnlLine2: Record "Gen. Journal Line";
        Currency: Record Currency;
        GLSetup: Record "General Ledger Setup";
        AmtRounding: Decimal;
        LinesCount: Integer;
        CurrentCount: Integer;
        DifferenceLCY: Decimal;
        CurrExchRate: Record "Currency Exchange Rate";
        VATAmt: Decimal;
        Amt: Decimal;
        AmtLCY: Decimal;
    begin
        if PurchHeader."Currency Code" <> '' then begin
            Currency.get(PurchHeader."Currency Code");
            AmtRounding := Currency."Amount Rounding Precision";
        end
        else begin
            GLSetup.get;
            AmtRounding := GLSetup."Amount Rounding Precision";
        end;

        Amt := TotalPurchLine."Amount Including VAT";
        AmtLCY := TotalPurchLineLCY."Amount Including VAT";

        if IsMultiPaymentTerm(PurchHeader."Payment Terms Code") then begin
            DocPaymentTerms.RESET;
            DocPaymentTerms.SETRANGE("Document Type", PurchHeader."Document Type");
            DocPaymentTerms.SETRANGE("Document No.", PurchHeader."No.");
            DocPaymentTerms.SETRANGE("Document Source", DocPaymentTerms."Document Source"::Purchase);
            LinesCount := DocPaymentTerms.Count;
            CurrentCount := 2;
            IF DocPaymentTerms.FINDFIRST THEN begin
                if DocPaymentTerms.Next <> 0 then
                    repeat
                        if CurrentCount = LinesCount then
                            DifferenceLCY := GetPurchaseDocumentPaymentTermsDifferenceLCY(DocPaymentTerms, TotalPurchLineLCY, AmtRounding);

                        Perc := DocPaymentTerms.Percentage / 100;
                        GenJnlLine2.Init;
                        GenJnlLine2.Copy(GenJnlLine);
                        GenJnlLine2.Amount := -Amt * Perc;
                        GenJnlLine2."Source Currency Amount" := -Amt * Perc;
                        GenJnlLine2."Amount (LCY)" := round((-AmtLCY * Perc), AmtRounding) - DifferenceLCY;
                        GenJnlLine2."Sales/Purch. (LCY)" := round((-AmtLCY * Perc), AmtRounding);
                        GenJnlLine2."Inv. Discount (LCY)" := round((-TotalPurchLineLCY."Inv. Discount Amount" * Perc), AmtRounding);
                        GenJnlLine2."Due Date" := DocPaymentTerms."Due Date";
                        GenJnlPostLine.RunWithCheck(GenJnlLine2);

                        CurrentCount += 1;
                    until DocPaymentTerms.Next = 0;
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Check Line", 'OnBeforeCheckPurchDocNoIsNotUsed', '', false, false)]
    local procedure OnGenJnlCheckLineOnBeforeCheckPurchDocNoIsNotUsed(var IsHandled: Boolean; GenJournalLine: Record "Gen. Journal Line")
    begin
        IsHandled := GenJournalLine."System-Created Entry";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Post Line", 'OnBeforeCheckPurchExtDocNoProcedure', '', false, false)]
    local procedure OnGenJnlPostLineOnBeforeCheckPurchExtDocNoProcedure(var GenJnlLine: Record "Gen. Journal Line"; var IsHandled: Boolean)
    var
        PurchSetup: Record "Purchases & Payables Setup";
    begin
        PurchSetup.Get();
        if not (PurchSetup."Ext. Doc. No. Mandatory" or (GenJnlLine."External Document No." <> '')) then
            exit;

        GenJnlLine.TestField("External Document No.");

        IsHandled := GenJnlLine."System-Created Entry";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Check Line", 'OnBeforeCheckSalesDocNoIsNotUsed', '', false, false)]
    local procedure OnGenJnlCheckLineOnBeforeCheckSalesDocNoIsNotUsed(var IsHandled: Boolean; GenJournalLine: Record "Gen. Journal Line")
    begin
        IsHandled := GenJournalLine."System-Created Entry";
    end;



    [EventSubscriber(ObjectType::Codeunit, Codeunit::"sales Post Invoice Events", 'OnPostLedgerEntryOnBeforeGenJnlPostLine', '', false, false)]
    local procedure OnSalesPostOnBeforePostCustomerEntry(VAR GenJnlLine: Record "Gen. Journal Line";
    VAR SalesHeader: Record "Sales Header";
    VAR TotalSalesLine: Record "Sales Line";
    VAR TotalSalesLineLCY: Record "Sales Line";
   SuppressCommit: Boolean;
    PreviewMode: Boolean)
    var
        Perc: Decimal;
        GenJnlLine2: Record "Gen. Journal Line";
        GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line";
        GLSetup: Record "General Ledger Setup";
        AmtRounding: Decimal;
        Currency: Record Currency;
        CurrExchRate: Record "Currency Exchange Rate";
        Amt: Decimal;
        AmtLCY: Decimal;
    begin
        if SalesHeader."Currency Code" <> '' then begin
            Currency.get(SalesHeader."Currency Code");
            AmtRounding := Currency."Amount Rounding Precision";
        end
        else begin
            GLSetup.get;
            AmtRounding := GLSetup."Amount Rounding Precision";
        end;

        Amt := TotalSalesLine."Amount Including VAT";
        AmtLCY := TotalSalesLineLCY."Amount Including VAT";

        if not IsMultiPaymentTerm(SalesHeader."Payment Terms Code") then begin
            GenJnlLine.Amount := -Amt;
            GenJnlLine."Source Currency Amount" := -Amt;
            GenJnlLine."Amount (LCY)" := round((-AmtLCY), AmtRounding);
            GenJnlLine."Sales/Purch. (LCY)" := round((-AmtLCY), AmtRounding);
            GenJnlLine."Inv. Discount (LCY)" := round((-TotalSalesLineLCY."Inv. Discount Amount"), AmtRounding);
            exit;
        end;

        DocPaymentTerms.RESET;
        DocPaymentTerms.SETRANGE("Document Type", SalesHeader."Document Type");
        DocPaymentTerms.SETRANGE("Document No.", SalesHeader."No.");
        DocPaymentTerms.SETRANGE("Document Source", DocPaymentTerms."Document Source"::Sales);
        IF DocPaymentTerms.FINDFIRST THEN begin
            Perc := DocPaymentTerms.Percentage / 100;

            GenJnlLine."Recurring Method" := GenJnlLine."Recurring Method"::"V  Variable";
            GenJnlLine.Amount := -Amt * Perc;
            GenJnlLine."Source Currency Amount" := -Amt * Perc;
            GenJnlLine."Amount (LCY)" := round((-AmtLCY * Perc), AmtRounding);
            GenJnlLine."Sales/Purch. (LCY)" := round((-AmtLCY * Perc), AmtRounding);
            GenJnlLine."Inv. Discount (LCY)" := round((-TotalSalesLineLCY."Inv. Discount Amount" * Perc), AmtRounding);
            GenJnlLine."Due Date" := DocPaymentTerms."Due Date";
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"sales Post Invoice Events", 'OnPostLedgerEntryOnAfterGenJnlPostLine', '', false, false)]
    local procedure OnSalesPostOnAfterPostCustomerEntry(VAR GenJnlLine: Record "Gen. Journal Line";
    SalesHeader: Record "Sales Header";
    VAR TotalSalesLine: Record "Sales Line";
    VAR TotalSalesLineLCY: Record "Sales Line";
    VAR GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line")
    var
        Perc: Decimal;
        GenJnlLine2: Record "Gen. Journal Line";
        GLSetup: Record "General Ledger Setup";
        AmtRounding: Decimal;
        Currency: Record Currency;
        LinesCount: Integer;
        CurrentCount: Integer;
        DifferenceLCY: Decimal;
        CurrExchRate: Record "Currency Exchange Rate";
        VATAmt: Decimal;
        Amt: Decimal;
        AmtLCY: Decimal;
    begin
        if SalesHeader."Currency Code" <> '' then begin
            Currency.get(SalesHeader."Currency Code");
            AmtRounding := Currency."Amount Rounding Precision";
        end
        else begin
            GLSetup.get;
            AmtRounding := GLSetup."Amount Rounding Precision";
        end;

        Amt := TotalSalesLine."Amount Including VAT";
        AmtLCY := TotalSalesLineLCY."Amount Including VAT";

        if IsMultiPaymentTerm(SalesHeader."Payment Terms Code") then begin
            DocPaymentTerms.RESET;
            DocPaymentTerms.SETRANGE("Document Type", SalesHeader."Document Type");
            DocPaymentTerms.SETRANGE("Document No.", SalesHeader."No.");
            DocPaymentTerms.SETRANGE("Document Source", DocPaymentTerms."Document Source"::Sales);
            LinesCount := DocPaymentTerms.Count;
            CurrentCount := 2;
            IF DocPaymentTerms.FINDFIRST THEN begin
                if DocPaymentTerms.Next <> 0 then
                    repeat
                        if CurrentCount = LinesCount then
                            DifferenceLCY := GetDocumentPaymentTermsDifferenceLCY(DocPaymentTerms, TotalSalesLineLCY, AmtRounding);

                        Perc := DocPaymentTerms.Percentage / 100;
                        GenJnlLine2.Init;
                        GenJnlLine2.Copy(GenJnlLine);
                        GenJnlLine2.Amount := -Amt * Perc;
                        GenJnlLine2."Source Currency Amount" := -Amt * Perc;
                        GenJnlLine2."Amount (LCY)" := round((-AmtLCY * Perc), AmtRounding) - DifferenceLCY;
                        GenJnlLine2."Sales/Purch. (LCY)" := round((-AmtLCY * Perc), AmtRounding);
                        GenJnlLine2."Inv. Discount (LCY)" := round((-TotalSalesLineLCY."Inv. Discount Amount" * Perc), AmtRounding);
                        GenJnlLine2."Due Date" := DocPaymentTerms."Due Date";
                        GenJnlPostLine.RunWithCheck(GenJnlLine2);

                        CurrentCount += 1;
                    until DocPaymentTerms.Next = 0;
            end;
        end;
    end;

    procedure GetDocumentPaymentTermsDifferenceLCY(var DocPaymentTerms: Record "Document Payment Terms"; VAR TotalSalesLineLCY: Record "Sales Line"; AmtRoundingPrecision: Decimal): Decimal
    var
        DocPaymentTerms2: Record "Document Payment Terms";
        TotalRoundedLCY: Decimal;
        Perc: Decimal;
        GLSetup: Record "General Ledger Setup";
        AmtLCY: Decimal;
    begin
        AmtLCY := TotalSalesLineLCY."Amount Including VAT";
        DocPaymentTerms2.Reset();
        DocPaymentTerms2.CopyFilters(DocPaymentTerms);
        if DocPaymentTerms2.FindFirst() then
            repeat
                Perc := DocPaymentTerms2.Percentage / 100;
                TotalRoundedLCY += round((-AmtLCY * Perc), AmtRoundingPrecision)
            until DocPaymentTerms2.Next() = 0;

        exit(TotalRoundedLCY + AmtLCY)
    end;

    [EventSubscriber(ObjectType::Table, 36, 'OnAfterValidateEvent', 'Payment Terms Code', false, false)]
    local procedure OnSalesHeaderOnValidatePaymentTermsCode(VAR Rec: Record "Sales Header"; VAR xRec: Record "Sales Header");
    var
        MultiPaymentTermsCU: Codeunit "Payment Terms Utilities";
        ClearSalesPymnTermDetails: Label 'Payment Term Code "%1" has details. \Changing it will result in deleting its details.\Do you want to continue?';
        DocSource: Option Sales,Purchase;
        GLSetup: Record "General Ledger Setup";
        Amt: Decimal;
    begin
        Rec.CalcFields("Payment Terms Exists");
        IF Rec."Payment Terms Code" <> xRec."Payment Terms Code" THEN BEGIN
            DocSource := DocSource::Sales;
            IF MultiPaymentTermsCU.IsMultiPaymentTerm(xRec."Payment Terms Code") THEN
                IF CONFIRM(ClearSalesPymnTermDetails, FALSE, xRec."Payment Terms Code") THEN BEGIN
                    MultiPaymentTermsCU.ClearPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource);
                END
                ELSE BEGIN
                    Rec := xRec;
                    EXIT;
                END;
            IF MultiPaymentTermsCU.IsMultiPaymentTerm(Rec."Payment Terms Code") THEN BEGIN

                Rec.CalcFields("Amount Including VAT");
                Amt := Rec."Amount Including VAT";

                MultiPaymentTermsCU.ClearPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource);
                MultiPaymentTermsCU.AddPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource, Amt, Rec."Document Date", Rec."Payment Terms Code");
            END
        END;
    end;

    [EventSubscriber(ObjectType::Table, 36, 'OnAfterValidateEvent', 'Currency Code', false, false)]
    local procedure OnSalesHeaderOnValidateCurrencyCode(VAR Rec: Record "Sales Header"; VAR xRec: Record "Sales Header");
    var
        DocSource: Option Sales,Purchase;
        MultiPaymentTermsCU: Codeunit "Payment Terms Utilities";
        GLSetup: Record "General Ledger Setup";
        Amt: Decimal;
    begin
        Rec.CalcFields("Payment Terms Exists");
        IF Rec."Payment Terms Exists" THEN BEGIN

            Rec.CalcFields("Amount Including VAT");
            Amt := Rec."Amount Including VAT";

            MultiPaymentTermsCU.ClearPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource::Sales);
            MultiPaymentTermsCU.AddPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource::Sales, Amt, Rec."Document Date", Rec."Payment Terms Code");
        END;
    END;

    [EventSubscriber(ObjectType::Table, 36, 'OnAfterValidateEvent', 'Document Date', false, false)]
    local procedure OnSalesHeaderOnValidateDocumentDate(VAR Rec: Record "Sales Header"; VAR xRec: Record "Sales Header");
    var
        DocSource: Option Sales,Purchase;
        UpdateDocumentDate: Boolean;
        MultiPaymentTermsCU: Codeunit "Payment Terms Utilities";
    begin
        IF xRec."Document Date" <> Rec."Document Date" THEN BEGIN
            Rec.CalcFields("Payment Terms Exists");
            IF Rec."Payment Terms Exists" THEN BEGIN
                DocSource := DocSource::Sales;
                MultiPaymentTermsCU.UpdateDocPaymentTerms(Rec."Document Type", Rec."No.", DocSource, Rec."Document Date");
            END
        end;
    End;

    [EventSubscriber(ObjectType::Table, 38, 'OnAfterValidateEvent', 'Payment Terms Code', false, false)]
    local procedure OnPaymentTermsCodeOnValidatePurchaseHeader(VAR Rec: Record "Purchase Header"; VAR xRec: Record "Purchase Header");
    var
        DocSource: Option Sales,Purchase;
        MultiPaymentTermsCU: Codeunit "Payment Terms Utilities";
        ClearPurchPymnTermDetails: Label 'Payment Term Code "%1" has details. \Changing it will result in deleting its details.\Do you want to continue?';
        GLSetup: Record "General Ledger Setup";
        Amt: Decimal;
    begin
        IF Rec."Payment Terms Code" <> xRec."Payment Terms Code" THEN BEGIN
            DocSource := DocSource::Purchase;
            xRec.CalcFields("Payment Terms Exists");
            IF xRec."Payment Terms Exists" THEN
                IF CONFIRM(ClearPurchPymnTermDetails, FALSE, xRec."Payment Terms Code") THEN BEGIN
                    MultiPaymentTermsCU.ClearPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource);
                END
                ELSE BEGIN
                    Rec := xRec;
                    EXIT;
                END;
            Rec.CalcFields("Payment Terms Exists");
            IF Rec."Payment Terms Exists" THEN BEGIN
                MultiPaymentTermsCU.ClearPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource);

                Rec.CalcFields("Amount Including VAT");
                Amt := Rec."Amount Including VAT";

                MultiPaymentTermsCU.AddPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource, Amt, Rec."Document Date", Rec."Payment Terms Code");
            END
        END;
    End;

    [EventSubscriber(ObjectType::Table, 38, 'OnAfterValidateEvent', 'Currency Code', false, false)]
    local procedure OnCurrencyCodeOnValidatePurchaseHeader(VAR Rec: Record "Purchase Header"; VAR xRec: Record "Purchase Header");
    var
        DocSource: Option Sales,Purchase;
        MultiPaymentTermsCU: Codeunit "Payment Terms Utilities";
        GLSetup: Record "General Ledger Setup";
        Amt: Decimal;
    begin
        Rec.CalcFields("Payment Terms Exists");
        IF Rec."Payment Terms Exists" THEN BEGIN

            Rec.CalcFields("Amount Including VAT");
            Amt := Rec."Amount Including VAT";

            MultiPaymentTermsCU.ClearPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource::Purchase);
            MultiPaymentTermsCU.AddPaymentTermDetails(Rec."Document Type", Rec."No.", DocSource::Purchase, Amt, Rec."Document Date", Rec."Payment Terms Code");
        END;
    End;

    [EventSubscriber(ObjectType::Table, 38, 'OnAfterValidateEvent', 'Document Date', false, false)]
    local procedure OnDocumentDateOnValidatePurchaseHeader(VAR Rec: Record "Purchase Header"; VAR xRec: Record "Purchase Header");
    var
        DocSource: Option Sales,Purchase;
        MultiPaymentTermsCU: Codeunit "Payment Terms Utilities";
        UpdateDocumentDate: Boolean;
    begin
        IF xRec."Document Date" <> Rec."Document Date" THEN BEGIN
            UpdateDocumentDate := TRUE;
            Rec.CalcFields("Payment Terms Exists");
            IF Rec."Payment Terms Exists" THEN BEGIN
                DocSource := DocSource::Purchase;
                MultiPaymentTermsCU.UpdateDocPaymentTerms(Rec."Document Type", Rec."No.", DocSource, Rec."Document Date");
            END;
        END;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Sales-Post", 'OnBeforePostSalesLines', '', false, false)]
    local procedure OnSalesPostOnBeforePostSalesLines(var SalesHeader: Record "Sales Header")
    var
        SalesLines: Record "Sales Line";
        MultiPaymentTerms: Record "Document Payment Terms";
        TotalLineAmount: Decimal;
    begin
        SalesHeader.CalcFields("Payment Terms Exists");
        if not SalesHeader."Payment Terms Exists" then
            exit;

        MultiPaymentTerms.Reset();
        MultiPaymentTerms.SetRange("Document Type", SalesHeader."Document Type");
        MultiPaymentTerms.SetRange("Document No.", SalesHeader."No.");
        MultiPaymentTerms.CalcSums(Percentage);
        MultiPaymentTerms.TestField(Percentage, 100);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Purch.-Post", 'OnBeforePostPurchLine', '', false, false)]
    local procedure OnPurchPostOnBeforePostPurchLine(var PurchHeader: Record "Purchase Header")
    var
        PurchLines: Record "Purchase Line";
        MultiPaymentTerms: Record "Document Payment Terms";
        TotalLineAmount: Decimal;
    begin
        PurchHeader.CalcFields("Payment Terms Exists");
        if not PurchHeader."Payment Terms Exists" then
            exit;

        MultiPaymentTerms.Reset();
        MultiPaymentTerms.SetRange("Document Type", PurchHeader."Document Type");
        MultiPaymentTerms.SetRange("Document No.", PurchHeader."No.");
        MultiPaymentTerms.CalcSums(Percentage);
        MultiPaymentTerms.TestField(Percentage, 100);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Sales-Post", 'OnAfterPostSalesDoc', '', false, false)]
    local procedure OnSalesPostOnAfterPostSalesDoc(SalesInvHdrNo: Code[20]; SalesCrMemoHdrNo: Code[20]; RetRcpHdrNo: Code[20]; var SalesHeader: Record "Sales Header")
    var
        MultiPaymentTerms: Record "Document Payment Terms";
        MultiPaymentTerms2: Record "Document Payment Terms";
    begin
        MultiPaymentTerms.Reset();
        MultiPaymentTerms.SetRange("Document Type", SalesHeader."Document Type");
        MultiPaymentTerms.SetRange("Document No.", SalesHeader."No.");
        if MultiPaymentTerms.FindFirst() then
            repeat
                if SalesInvHdrNo <> '' then begin
                    Clear(MultiPaymentTerms2);
                    MultiPaymentTerms2.Reset();
                    MultiPaymentTerms2 := MultiPaymentTerms;
                    MultiPaymentTerms2."Document Type" := MultiPaymentTerms2."Document Type"::"Posted Sales Invoice";
                    MultiPaymentTerms2."Document No." := SalesInvHdrNo;
                    MultiPaymentTerms2.Insert(true);
                end;
                if SalesCrMemoHdrNo <> '' then begin
                    Clear(MultiPaymentTerms2);
                    MultiPaymentTerms2.Reset();
                    MultiPaymentTerms2 := MultiPaymentTerms;
                    MultiPaymentTerms2."Document Type" := MultiPaymentTerms2."Document Type"::"Posted Sales Credit Memo";
                    MultiPaymentTerms2."Document No." := SalesCrMemoHdrNo;
                    MultiPaymentTerms2.Insert(true);
                end;
            until MultiPaymentTerms.Next() = 0;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Purch.-Post", 'OnAfterPostPurchaseDoc', '', false, false)]
    local procedure OnPurchPostOnAfterPostPurchaseDoc(PurchInvHdrNo: Code[20]; PurchRcpHdrNo: Code[20]; PurchCrMemoHdrNo: Code[20]; var PurchaseHeader: Record "Purchase Header")
    var
        MultiPaymentTerms: Record "Document Payment Terms";
        MultiPaymentTerms2: Record "Document Payment Terms";
    begin
        MultiPaymentTerms.Reset();
        MultiPaymentTerms.SetRange("Document Type", PurchaseHeader."Document Type");
        MultiPaymentTerms.SetRange("Document No.", PurchaseHeader."No.");
        if MultiPaymentTerms.FindFirst() then
            repeat
                if PurchInvHdrNo <> '' then begin
                    Clear(MultiPaymentTerms2);
                    MultiPaymentTerms2.Reset();
                    MultiPaymentTerms2 := MultiPaymentTerms;
                    MultiPaymentTerms2."Document Type" := MultiPaymentTerms2."Document Type"::"Posted Purchase Invoice";
                    MultiPaymentTerms2."Document No." := PurchInvHdrNo;
                    MultiPaymentTerms2.Insert(true);
                end;
                if PurchCrMemoHdrNo <> '' then begin
                    Clear(MultiPaymentTerms2);
                    MultiPaymentTerms2.Reset();
                    MultiPaymentTerms2 := MultiPaymentTerms;
                    MultiPaymentTerms2."Document Type" := MultiPaymentTerms2."Document Type"::"Posted Purchase Credit Memo";
                    MultiPaymentTerms2."Document No." := PurchCrMemoHdrNo;
                    MultiPaymentTerms2.Insert(true);
                end;
            until MultiPaymentTerms.Next() = 0;
    end;

    local procedure GetPurchaseDocumentPaymentTermsDifferenceLCY(var DocPaymentTerms: Record "Document Payment Terms"; VAR TotalPurchaseLineLCY: Record "Purchase Line"; AmtRoundingPrecision: Decimal): Decimal
    var
        DocPaymentTerms2: Record "Document Payment Terms";
        TotalRoundedLCY: Decimal;
        Perc: Decimal;
        GLSetup: Record "General Ledger Setup";
        AmtLCY: Decimal;
    begin
        AmtLCY := TotalPurchaseLineLCY."Amount Including VAT";

        DocPaymentTerms2.Reset();
        DocPaymentTerms2.CopyFilters(DocPaymentTerms);
        if DocPaymentTerms2.FindFirst() then
            repeat
                Perc := DocPaymentTerms2.Percentage / 100;
                TotalRoundedLCY += round((-AmtLCY * Perc), AmtRoundingPrecision)
            until DocPaymentTerms2.Next() = 0;

        exit(TotalRoundedLCY + AmtLCY)
    end;
}
