table 68236 "Document Payment Terms"
{
    PasteIsValid = false;

    fields
    {
        field(1; "Document Type"; Enum "Document Type")
        {
            Caption = 'Document Type';
            // OptionCaption = 'Quote,Order,Invoice,Credit Memo,Blanket Order,Return Order,Posted Sales Invoice,Posted Sales Credit Memo,Posted Return Receipt';
            // OptionMembers = Quote,"Order",Invoice,"Credit Memo","Blanket Order","Return Order","Posted Sales Invoice","Posted Sales Credit Memo","Posted Return Receipt";
        }
        field(2; "Document No."; Code[20])
        {
        }
        field(3; "Payment Term Code"; Code[10])
        {
            TableRelation = "Payment Terms";
        }
        field(4; "Due Date Calculation"; DateFormula)
        {

            trigger OnValidate();
            begin
                HeaderDocDate := MultiPaymentTermsCU.GetHeaderDocumentDate("Document Type", "Document No.", "Document Source", HeaderExists);
                IF HeaderExists THEN
                    "Due Date" := CALCDATE("Due Date Calculation", HeaderDocDate);
            end;
        }
        field(5; Percentage; Decimal)
        {

            trigger OnValidate();
            begin
                HeaderAmount := MultiPaymentTermsCU.GetHeaderAmount("Document Type", "Document No.", "Document Source", HeaderExists);
                // IF HeaderExists THEN
                //     Amount := (HeaderAmount * Percentage) / 100;
            end;
        }
        // field(6; Amount; Decimal)
        // {

        //     trigger OnValidate();
        //     begin
        //         HeaderAmount := MultiPaymentTermsCU.GetHeaderAmount("Document Type", "Document No.", "Document Source", HeaderExists);
        //         IF HeaderExists THEN
        //             Percentage := (Amount * 100) / HeaderAmount;
        //     end;
        // }
        field(7; "Due Date"; Date)
        {
        }
        field(8; Description; Text[50])
        {
        }
        field(9; "Line No."; Integer)
        {
        }
        field(10; "Document Source"; Option)
        {
            OptionCaption = 'Sales,Purchase';
            OptionMembers = Sales,Purchase;
        }
    }

    keys
    {
        key(Key1; "Document Type", "Document No.", "Line No.")
        {
        }
        key(Key2; "Document Type", "Document No.", "Payment Term Code", "Document Source", "Due Date Calculation")
        {
        }
        key(Key3; "Due Date")
        {
        }
    }
    fieldgroups
    {
    }
    var
        HeaderDocDate: Date;
        HeaderAmount: Decimal;
        MultiPaymentTermsCU: Codeunit "Payment Terms Utilities";
        HeaderExists: Boolean;
        SalesHeader: Record "Sales Header";
        PurchHeader: Record "Purchase Header";

    procedure InitilizeRec(DocSource: Option Sales,Purchase);
    begin
        IF DocSource = DocSource::Sales THEN BEGIN
            SalesHeader.SETRANGE("No.", "Document No.");
            IF SalesHeader.FINDFIRST THEN BEGIN
                "Document Type" := SalesHeader."Document Type";
                "Payment Term Code" := SalesHeader."Payment Terms Code";
                "Document Source" := DocSource;
                Rec.CALCSUMS(Percentage);
                Percentage := 100 - Rec.Percentage;
                VALIDATE(Percentage);
            END
        END
        ELSE BEGIN
            PurchHeader.SETRANGE("No.", "Document No.");
            IF PurchHeader.FINDFIRST THEN BEGIN
                "Document Type" := PurchHeader."Document Type";
                "Payment Term Code" := PurchHeader."Payment Terms Code";
                "Document Source" := DocSource;
                Rec.CALCSUMS(Percentage);
                Percentage := 100 - Rec.Percentage;
                VALIDATE(Percentage);
            END
        END
    end;

    procedure IsHundredPercent(DocSource: Option Sales,Purchase;
    DocType: enum "Document Type";
    DocNo: Code[20]) FullPercent: Boolean
    var
        TotalPercent: Decimal;
        DocPaymentTerm: Record "Document Payment Terms";
    begin
        TotalPercent := 0;
        DocPaymentTerm.SETRANGE("Document Type", DocType);
        DocPaymentTerm.SETRANGE("Document No.", DocNo);
        DocPaymentTerm.SETRANGE("Document Source", DocSource);
        IF DocPaymentTerm.FINDFIRST THEN begin
            REPEAT
                TotalPercent += DocPaymentTerm.Percentage;
            UNTIL DocPaymentTerm.NEXT = 0;
        end
        else
            exit(true);
        EXIT(TotalPercent = 100)
    end;
}
