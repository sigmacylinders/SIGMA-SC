pageextension 68235 "PT-Sales Order" extends "Sales Order"
{
    layout
    {
        addafter("Invoice Details")
        {
            part(DocPymtTerms; "Sales Payment Terms")
            {
                ApplicationArea = All;
                Editable = Rec."Payment Terms Exists";
                SubPageLink = "Document No." = FIELD("No."), "Payment Term Code" = FIELD("Payment Terms Code"), "Document Type" = FIELD("Document Type");
            }
        }
    }

    trigger OnAfterGetRecord()
    begin
        Rec.CalcFields("Payment Terms Exists");
    end;
}