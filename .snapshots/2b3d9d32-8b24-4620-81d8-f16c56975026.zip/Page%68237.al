page 68237 "Sales Payment Terms"
{
    AutoSplitKey = true;
    DelayedInsert = true;
    MultipleNewLines = true;
    PageType = ListPart;
    SourceTable = "Document Payment Terms";
    SourceTableView = SORTING("Due Date");
    ApplicationArea = All;

    layout
    {
        area(content)
        {
            repeater(Group)
            {
                field("Due Date Calculation"; Rec."Due Date Calculation")
                {
                    ApplicationArea = All;
                }
                field(Percentage; Rec.Percentage)
                {
                    ApplicationArea = All;
                }
                field("Due Date"; Rec."Due Date")
                {
                    ApplicationArea = All;
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;
                }
            }
        }
    }

    trigger OnNewRecord(BelowxRec: Boolean);
    var
        DocSource: Option Sales,Purchase;
    begin
        DocSource := DocSource::Sales;
        Rec.InitilizeRec(DocSource);
    end;

    trigger OnQueryClosePage(CloseAction: Action): Boolean;
    var
        ErrorString001: Label 'Payment Term Details Percentage must total to 100';
    begin
        IF NOT Rec.IsHundredPercent(Rec."Document Source", Rec."Document Type", Rec."Document No.") THEN ERROR(ErrorString001);
        exit(true);
    end;
}
